import classes from "./Form.module.css";

export default function Form() {
  return (
    <>
      <div className={classes["form-main-wrapper"]}>
        <div className={classes["form-wrapper"]}>
          <div className={classes["form-title"]}>Fill this form to add new students</div>
          <form>
            <div className={classes["form-row"]}>
              <label htmlFor="name">Name </label>
              <input id="name" type="text" name="name" />
            </div>

            <div className={classes["form-row"]}>
              <label htmlFor="age"> Age </label>
              <input id="age" type="number" name="age" />
            </div>

            <div className={classes["form-row"]}>
              <label htmlFor="student-id">Student ID</label>
              <input id="student-id" type="number" name="student-id" />
            </div>
            <div className={classes["form-row"]}>
              <label htmlFor="contact-no">Contact No.</label>
              <input id="contact-no" type="number" name="contact-no" />
            </div>
            <div className={classes["form-row"]}>
              <label htmlFor="email">Email</label>
              <input id="email" type="email" name="email" />
            </div>
            <div className={classes["form-row"]}>
              <label htmlFor="city">City</label>
              <input id="city" type="text" name="city" />
            </div>
            <div className={classes["form-row"]}>
              <label htmlFor="state">State</label>
              <input id="state" type="text" name="state" />
            </div>
            <div className={classes["button-wrapper"]}>
              <button type="submit">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
