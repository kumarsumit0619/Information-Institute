import classes from "./Header.module.css"

export default function Header() {
  return (
    <>
      <header className={classes["main-header"]}>Students Detail Form</header>
      
    </>
  );
}
