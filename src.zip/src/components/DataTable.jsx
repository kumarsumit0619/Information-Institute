import classes from './DataTable.module.css';

const DUMMY_DATA = [
    {
      name: "John Doe",
      age: 24,
      "student-id": 55567,
      "contact-no": 9956564545,
      email: "john.doe@gmail.com",
      city: "Pune",
      state: "Maharashtra",
    },
    {
      name: "Kelly James",
      age: 26,
      "student-id": 67563,
      "contact-no": 8899445562,
      email: "kelly.james@gmail.com",
      city: "Bangaluru",
      state: "Karnataka",
    },
    {
      name: "Allen Copper",
      age: 21,
      "student-id": 45687,
      "contact-no": 8976453325,
      email: "allen.copper@gmail.com",
      city: "Hyderabad",
      state: "Telangana",
    },
  ];
export default function DataTable(){
    return (<table className={classes["dataTable"]} cellspacing="0" cellpadding="0" border="0">
    <tr>
      <th>Name</th>
      <th>Age</th>
      <th>Student ID</th>
      <th>Contact No</th>
      <th>Email</th>
      <th>City</th>
      <th>State</th>
      <th>Actions</th>
    </tr>
    <tr>
      <td>{DUMMY_DATA[0].name}</td>
      <td>{DUMMY_DATA[0].age}</td>
      <td>{DUMMY_DATA[0]["student-id"]}</td>
      <td>{DUMMY_DATA[0]["contact-no"]}</td>
      <td>{DUMMY_DATA[0].email}</td>
      <td>{DUMMY_DATA[0].city}</td>
      <td>{DUMMY_DATA[0].state}</td>
      <td>
        <button type="button">Edit</button>
        <button type="button">Delete</button>
      </td>
    </tr>
    <tr>
      <td>{DUMMY_DATA[1].name}</td>
      <td>{DUMMY_DATA[1].age}</td>
      <td>{DUMMY_DATA[1]["student-id"]}</td>
      <td>{DUMMY_DATA[1]["contact-no"]}</td>
      <td>{DUMMY_DATA[1].email}</td>
      <td>{DUMMY_DATA[1].city}</td>
      <td>{DUMMY_DATA[1].state}</td>
      <td>
        <button type="button">Edit</button>
        <button type="button">Delete</button>
      </td>
    </tr>

    <tr>
      <td>{DUMMY_DATA[2].name}</td>
      <td>{DUMMY_DATA[2].age}</td>
      <td>{DUMMY_DATA[2]["student-id"]}</td>
      <td>{DUMMY_DATA[2]["contact-no"]}</td>
      <td>{DUMMY_DATA[2].email}</td>
      <td>{DUMMY_DATA[2].city}</td>
      <td>{DUMMY_DATA[2].state}</td>
      <td>
        <button type="button">Edit</button>
        <button type="button">Delete</button>
      </td>
    </tr>
  </table>);
}